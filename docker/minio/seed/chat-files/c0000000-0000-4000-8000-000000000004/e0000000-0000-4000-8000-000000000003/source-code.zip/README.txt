File ZIP mau cho demo S-Call.
Nhom 6 - IT4409
